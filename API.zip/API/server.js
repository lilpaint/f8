var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var exphbs  = require('express-handlebars');
var mysql = require('mysql');
var session = require('express-session');
var FormData = require('form-data');
var axios = require('axios');
const { Cookie } = require('express-session');
var url = require('url');
var https = require('https');
var queryString = require('querystring');
var fs = require('fs');
const HttpsProxyAgent = require('https-proxy-agent');
const { Agent } = require('http');
var request = require('request');

app.engine('hbs', exphbs({
    extname: '.hbs'
  }));
app.set('view engine', 'hbs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.set('views', './views');
app.get('/', function (req, res) {
    return res.render('home')
});
var db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Fakepw1-',
    database: 'group'
});
db.connect();


app.get('/', function(request, response) {
	response.sendFile(path.join(__dirname + 'views/home.hbs'));
});




app.post('/check', async function(req, res, next) {
    let keyserial = req.body.keyserial;
    let code = req.body.code;
    let sql = 'SELECT * FROM account WHERE keyserial = ? AND code = ?';
    if(!keyserial || !code){
        res.send("error")
    }
    else{
        db.query(sql, [keyserial, code] , (err, rows) => {   
            if (rows.length <= 0 ) { res.send("Key Expired")}
            else {
                res.send({ keyserial: rows[0].keyserial, expire: rows[0].expire, keyproxy: rows[0].keyproxy });
            }
        });   
    }
   });



app.post('/account/update', function (req, res) {
    let proxy = req.body.proxy;
    let useragent = req.body.useragent;
    let keyserial = req.body.keyserial;
    db.query("UPDATE account SET useragent = ?, proxy = ? WHERE keyserial = ?", [useragent, proxy, keyserial], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'users list.' });
    });
});

app.post('/account/proxy', function (req, res) {
    let keyproxy = req.body.keyproxy;
    let keyserial = req.body.keyserial;
    db.query("UPDATE account SET keyproxy = ? WHERE keyserial = ?", [keyproxy, keyserial], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'users list.' });
    });
});



app.get('/update', async function(req, res, next) {
    var sql = "SELECT * FROM account"
    var listkey1 = new Array()
    db.query(sql, (err, rows) => {  
        rows.forEach(function(x){
            var keyproxy = x.keyproxy;
            var listkey = keyproxy.split("|")
            listkey.forEach(function(key){
                listkey1.push(key);
            })
            
        });
        let x = listkey1.filter((v,i) => listkey1.indexOf(v) === i)
        console.log(x);
        x.forEach(function(key1){
            var options = {
                    'method': 'GET',
                    'url': 'http://proxy.tinsoftsv.com/api/changeProxy.php?key='+ key1+'&location=1',
                  };
                   request(options, function (error, response) {
                    if (error) {
                    }else{
                        console.log("Done");
                    }
                    });
        })

        
    })
})





   app.post('/getcookie', async function(req, res, next) {
    let email = req.body.email
    let pass = req.body.pass
    let keyserial = req.body.keyserial
    let code = req.body.code
    let sql = 'SELECT * FROM account WHERE keyserial = ? AND code = ?';
        if(!email || !pass || !keyserial || !code){
            res.send("Thiếu Parameter")
            console.log("Thiếu param")
        }
        else{
            db.query(sql, [keyserial, code] , (err, rows) => {   
                if (rows.length <= 0 ) { res.send("Key Expired")}
                else {
                    var options = {
                        'method': 'POST',
                        'url': 'https://iphone.facebook.com/login.php',
                        'headers': {
                            'User-Agent': rows[0].useragent, 
                            'Cookie': ''
                        },
                        proxy: 'http://'+rows[0].proxy+'/',
                        formData: {
                          'email': email,
                          'pass': pass,
                          'login': 'Login'
                        }
                      };
                      request(options, function (error, response) {
                        if (error) {
                            console.log("Loi")
                        }else{
                            var cookies = response.headers['set-cookie'];
                            var regexc_user = /c_user=[0-9]{0,}/
                            var regexxs = /xs=[0-9a-zA-Z_.%-]{0,}/
                            var c_user = regexc_user.exec(cookies)+'; '
                            var xs = regexxs.exec(cookies)+'; '
                            var cookie = c_user + xs;
                            console.log(cookie)
                            res.send(cookie);
                        }
                        });
                }})
            
        
        }
    })

    app.post('/join1', async function(req, res, next) {
        let idgroup = req.body.idgroup;
        let cookie = req.body.cookie;
        let keyserial = req.body.keyserial;
        let code = req.body.code;
        let sql = 'SELECT * FROM account WHERE keyserial = ? AND code = ?';
        if(!idgroup || !cookie || !keyserial || !code){
            res.send("error")
            console.log("Thieu param")
        }
        else{
            db.query(sql, [keyserial, code] , (err, rows) => {   
                if (rows.length <= 0 ) { res.send("Key Expired")}
                else {
                    var listid = idgroup.split("|")
                    console.log(listid)
                    listid.forEach(function(x){
                        var c = getData(x, cookie);
                        console.log(c)
                        var options = {
                            'method': 'GET',
                            'url': 'https://mbasic.facebook.com/groups/'+x+'?view=info',
                            'headers': {
                              'Content-Type': 'text/html; charset=utf-8', 
                              'Cookie': cookie,
                              'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0_6 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11B651 Safari/9537.53'
                            },
                          };
                            request(options, function (error, response) {
                            if (error) throw new Error(error);
                            var re = /gfid.[A-Za-z0-9]{3,}/
                            var stringkey = re.exec(response.body)
                            if(stringkey != ""){
                                var options1 = {
                                'method': 'GET',
                                'url': 'https://mbasic.facebook.com/a/group/join/?group_id='+x+'&is_redirect_to_info=1&'+stringkey+'&refid=18',
                                'headers': {
                                    'Content-Type': 'text/html; charset=utf-8', 
                                    'Cookie': cookie,
                                    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0_6 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11B651 Safari/9537.53'
                                },
                                };
                                request(options1, function (error, response) {
                                if (error) throw new Error(error);
                                console.log("Thanh cong")
                                })
                            }
                        })

                    })
                }
            });   
        }
       });


app.post('/join', async function(req, res, next) {
    let idgroup = req.body.idgroup;
    let cookie = req.body.cookie;
    let keyserial = req.body.keyserial;
    let code = req.body.code;
    let sql = 'SELECT * FROM account WHERE keyserial = ? AND code = ?';
    if(!idgroup || !cookie || !keyserial || !code){
        res.send("error")
        console.log("Thieu param")
    }
    else{
        db.query(sql, [keyserial, code] , (err, rows) => {   
            if (rows.length <= 0 ) { res.send("Key Expired")}
            else {
                axios.get('https://mbasic.facebook.com/groups/'+idgroup+'?view=info', {
                
                    headers: { 
                        'Content-Type': 'application/json', 
                        'Cookie': cookie
                      },
                    })
                    .then(function (response) {
                        var re = /gfid.[A-Za-z0-9]{3,}/
                        var stringnkey = re.exec(response.data)
                        if(stringnkey != ""){
                            axios.get('https://mbasic.facebook.com/a/group/join/?group_id='+idgroup+'&is_redirect_to_info=1&'+stringnkey+'&refid=18', {
                    
                            headers: { 
                            'Content-Type': 'application/json',
                            'Cookie': cookie
                            },
                            })
                            .then(function (response) {
                                res.send("Success");
                                console.log("Thành công")
                            })
                            .catch(function (error) {
                                console.log(error);
                            });
                        }
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
                    
                    
            }
        });   
    }
   });

app.post('/data/addua', function (req, res) {
    let useragent = req.body.useragent;
    db.query("INSERT INTO data SET useragent = ?", [useragent], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'users list.' });
    });
});

app.post('/data/getua', function (req, res) {
    let id = req.body.id
    let sql = 'SELECT * FROM data WHERE id = ?';
    db.query(sql, [id], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'users list.' });
    });
});



    
app.listen(3000, function () {
    console.log('Node app is running on port 3000');
});



module.exports = app;