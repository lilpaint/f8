var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var exphbs  = require('express-handlebars');
var mysql = require('mysql');
var session = require('express-session');
var FormData = require('form-data');
var axios = require('axios');
const { Cookie } = require('express-session');
var url = require('url');
var https = require('https');
var queryString = require('querystring');
var fs = require('fs');
const HttpsProxyAgent = require('https-proxy-agent');
const { Agent } = require('http');
var request = require('request');

app.engine('hbs', exphbs({
    extname: '.hbs'
  }));
app.set('view engine', 'hbs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.set('views', './views');
app.get('/', function (req, res) {
    return res.render('home')
});
var db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Fakepw1-',
    database: 'group'
});
db.connect();


app.get('/', function(request, response) {
	response.sendFile(path.join(__dirname + 'views/home.hbs'));
});




app.post('/check', async function(req, res, next) {
    let keyserial = req.body.keyserial;
    let code = req.body.code;
    let sql = 'SELECT * FROM account WHERE keyserial = ? AND code = ?';
    if(!keyserial || !code){
        res.send("error")
    }
    else{
        db.query(sql, [keyserial, code] , (err, rows) => {   
            if (rows.length <= 0 ) { res.send("Key Expired")}
            else {
                res.send({ keyserial: rows[0].keyserial, expire: rows[0].expire, keyproxy: rows[0].keyproxy });
            }
        });   
    }
   });

// app.post('/getcookie', async function(req, res, next) {
//     let email = req.body.email;
//     let password = req.body.password;
//     let keyserial = req.body.keyserial;
//     let code = req.body.code;
//     let sql = 'SELECT * FROM account WHERE keyserial = ? AND code = ?';
//     if(!email || !password || !keyserial || !code){
//         res.send("error")
//     }
//     else{
//         db.query(sql, [keyserial, code] , (err, rows) => {   
//             if (rows.length <= 0 ) { res.send("Key Expired")}
//             else {
//                 axios.get('https://vnlike.net/cookie/get.php', {
//                 params: {
//                   u: email,
//                   p: password
//                 }
//                 })
//                 .then(function (response) {
//                     res.send(response.data.cookie);
//                     console.log(response.data.cookie)
//                 })
//                 .catch(function (error) {
//                     console.log(error);
//                 });
//             }
//         });   
//     }
//    });




app.post('/account/update', function (req, res) {
    let proxy = req.body.proxy;
    let useragent = req.body.useragent;
    let keyserial = req.body.keyserial;
    db.query("UPDATE account SET useragent = ?, proxy = ? WHERE keyserial = ?", [useragent, proxy, keyserial], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'users list.' });
    });
});

app.get('/update', async function(req, res, next) {
    let proxy = "";
    let useragent = "";
    var sql = "SELECT * FROM account"
    db.query(sql, (err, rows) => {  
        for(var x = 0; x < rows.length; x++){
            var keyproxy = rows[x].keyproxy;
            var keyserial = rows[x].keyserial;
            axios.get('http://proxy.tinsoftsv.com/api/changeProxy.php?key='+ keyproxy+'&location=1', {
              })
              .then(function (response) {
                axios.get('http://proxy.tinsoftsv.com/api/getProxy.php?key='+keyproxy, {
                    })
                    .then(function (response) {
                        proxy = response.data.proxy
                        console.log(proxy)
                        var id = [Math.floor(Math.random() * 550)];
                        axios.post('http://localhost:3000/data/getua', {
                                    id: id
                            })
                            .then(function (response) {
                                useragent = response.data.data[0].useragent
                                console.log(useragent)
                                console.log(keyserial)
                                axios.post('http://localhost:3000/account/update', {
                                    proxy: proxy,
                                    useragent: useragent,
                                    keyserial: keyserial
                                  })
                                  .then(function (response) {
                                      res.send("Xong");
                                  })
                                  .catch(function (error) {
                                    res.send("Xong");
                                  });
                                

                            })
                            .catch(function (error) {
                            });


                    })
                
                    .catch(function (error) {
                    });
                })
            .catch(function (error) {
            });
        }
    })
})


app.post('/getcookie1', async function(req, res, next) {
    var options = {
        'method': 'POST',
        'url': 'https://whatismyip.host/',
        'headers': {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
        },
        proxy: 'http://27.76.191.2:21714',
      };
      request(options, function (error, response) {
        if (error) {
            console.log("Loi")
        }else{
            console.log(response.body)
        }
        });
    })


   app.post('/getcookie', async function(req, res, next) {
    let email = req.body.email
    let pass = req.body.pass
    let keyserial = req.body.keyserial
    let code = req.body.code
    let sql = 'SELECT * FROM account WHERE keyserial = ? AND code = ?';
        if(!email || !pass || !keyserial || !code){
            res.send("Thiếu Parameter")
            console.log("Thiếu param")
        }
        else{
            db.query(sql, [keyserial, code] , (err, rows) => {   
                if (rows.length <= 0 ) { res.send("Key Expired")}
                else {
                    var options = {
                        'method': 'POST',
                        'url': 'https://iphone.facebook.com/login.php',
                        'headers': {
                            'User-Agent': row[0].useragent, 
                            'Cookie': ''
                        },
                        proxy: 'http://'+row[0].proxy+'/',
                        formData: {
                          'email': email,
                          'pass': pass,
                          'login': 'Login'
                        }
                      };
                      request(options, function (error, response) {
                        if (error) {
                            console.log("Loi")
                        }else{
                            var cookies = response.headers['set-cookie'];
                            var regexc_user = /c_user=[0-9]{0,}/
                            var regexxs = /xs=[0-9a-zA-Z_.%-]{0,}/
                            var c_user = regexc_user.exec(cookies)+'; '
                            var xs = regexxs.exec(cookies)+'; '
                            var cookie = c_user + xs;
                            console.log(cookie)
                            res.send(cookie);
                        }
                        });
                }})
            
        
        }
    })


app.post('/join', async function(req, res, next) {
    let idgroup = req.body.idgroup;
    let cookie = req.body.cookie;
    let keyserial = req.body.keyserial;
    let code = req.body.code;
    let sql = 'SELECT * FROM account WHERE keyserial = ? AND code = ?';
    if(!idgroup || !cookie || !keyserial || !code){
        res.send("error")
        console.log("Thieu param")
    }
    else{
        db.query(sql, [keyserial, code] , (err, rows) => {   
            if (rows.length <= 0 ) { res.send("Key Expired")}
            else {
                axios.get('https://mbasic.facebook.com/groups/'+idgroup+'?view=info', {
                
                    headers: { 
                        'Content-Type': 'application/json', 
                        'Cookie': cookie
                      },
                })
                .then(function (response) {
                    var re = /gfid.[A-Za-z0-9]{3,}/
                    var stringnkey = re.exec(response.data)
                    if(stringnkey != ""){
                        axios.get('https://mbasic.facebook.com/a/group/join/?group_id='+idgroup+'&is_redirect_to_info=1&'+stringnkey+'&refid=18', {
                
                        headers: { 
                        'Content-Type': 'application/json',
                        'Cookie': cookie
                         },
                        })
                        .then(function (response) {
                            res.send("Success");
                            console.log("Thành công")
                        })
                        .catch(function (error) {
                            console.log(error);
                        });
                    }
                })
                .catch(function (error) {
                    console.log(error);
                });
            }
        });   
    }
   });

app.post('/data/addua', function (req, res) {
    let useragent = req.body.useragent;
    db.query("INSERT INTO data SET useragent = ?", [useragent], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'users list.' });
    });
});

app.post('/data/getua', function (req, res) {
    let id = req.body.id;
    db.query("SELECT * FROM data WHERE id = ?", [id], function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'users list.' });
    });
});



    
app.listen(3000, function () {
    console.log('Node app is running on port 3000');
});



module.exports = app;